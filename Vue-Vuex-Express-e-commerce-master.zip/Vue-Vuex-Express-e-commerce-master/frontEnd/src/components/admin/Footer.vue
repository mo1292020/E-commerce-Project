
<template>
 <div id="Footer">
   <footer class="bg-light text-center text-lg-start">
     <!-- Copyright -->
     <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
       © 2020 Copyright:
       <a class="text-dark" href="https://mdbootstrap.com/">MDBootstrap.com</a>
     </div>
     <!-- Copyright -->
   </footer>
 </div>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>
footer{
  position: fixed;
  bottom: 0;
  width: 100%;
}
</style>
