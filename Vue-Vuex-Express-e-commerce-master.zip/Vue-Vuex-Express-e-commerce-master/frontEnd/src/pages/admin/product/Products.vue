<template>
    <div class="container-fluid">
      <list-product/>
    </div>
</template>

<script>
import ListProduct from "@/components/admin/product/listProduct/ListProduct";
export default {
name: "products",
  components:{ListProduct}
}
</script>

<style scoped>

</style>
