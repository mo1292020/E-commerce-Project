<template>

        <list-user/>

</template>

<script>
import ListUser from '@/components/admin/user/listUser'
export default {
    name: 'users',
    components: { ListUser },
}
</script>

<style scoped>

</style>