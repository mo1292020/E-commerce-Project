<template>
 <list-order/>
</template>

<script>
import ListOrder from '@/components/admin/order/ListOrder'
export default {
    name: 'Order',
    components: { ListOrder },
}
</script>

<style scoped>

</style>