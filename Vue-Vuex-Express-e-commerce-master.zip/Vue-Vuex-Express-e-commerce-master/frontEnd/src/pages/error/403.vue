<template>
    <div id="403" class='text-center'>
        <p>intrusion attempt</p>
    </div>
</template>

<script>
export default {
    name: '403',
}
</script>

<style scoped>

</style>