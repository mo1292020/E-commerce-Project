<template>
   <div id="404" class='text-center'>
      <p>not Found</p>
   </div>
</template>

<script>
export default {
name: "404"
}
</script>

<style scoped>

</style>
