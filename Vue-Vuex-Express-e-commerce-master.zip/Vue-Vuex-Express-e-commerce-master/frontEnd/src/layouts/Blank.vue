<template>
 <div>
   <slot/>
 </div>
</template>

<script>
export default {
  name: "Blank"
}
</script>

<style scoped>

</style>
